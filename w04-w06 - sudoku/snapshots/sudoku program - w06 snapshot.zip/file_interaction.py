"""
Program: Lab 05 - Sudoku
FILE INTERACTION MODULES
"""

def load_board(filename="boards/board.json"):
    debug("load_board() called.")
    return filename, get_board(filename)


def load_user_board(filename="boards/user_board.json"):
    debug("load_user_board() called.")
    return filename, get_board(filename)


def save_board(user_board:list, user_board_filename:str="boards/user_board.json"):
    debug("save_board() called.")

    with open("boards/user_board.json") as file:
        board_json = json.dumps( { "board": user_board } )
        file.write(board_json)

    return True


import json
def get_board(board_filename):
    debug("get_board() called.")
    try:
        with open(board_filename) as file:
            board = json.load(file)

    except FileNotFoundError as error:
        debug(error)
        return get_empty_board()
    
    else:
        board = board["board"]
        return board


def get_empty_board():
    return [
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0]
    ]

# define
from debug import debug
class InvalidBoard(Exception):
    def __init__(self, msg="Invalid Board! Getting Empty board..."):
        super().__init__(msg)