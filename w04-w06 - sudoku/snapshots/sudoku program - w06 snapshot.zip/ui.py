"""
Program: Lab 05 - Sudoku
UI MODULES
"""

# import
from debug import debug
from validation import (
    validate_input,
    is_filled_square,
    apply_game_rules
)

# define
column_positions = { 'A':0, 'B':1, 'C':2, 'D':3, 'E':4, 'F':5, 'G':6, 'H':7, 'I':8 }

"""
PROMPT
"""
def prompt(board, user_board):
    debug("in ui.py: prompt() called.")
    while True:

        # display prompt
        user_input = input("> ").capitalize()

        # handle input
        if   user_input == 'Q': return user_board
        elif user_input == 'W': return False
        elif user_input == 'C': display_commands()
        elif user_input == 'D': display_board(board, user_board)
        elif user_input == 'E': try_filling_square("prompt",   board, user_board)
        else:                   try_filling_square(user_input, board, user_board)

        print()


"""
BOARD: EDIT
"""
def try_filling_square(user_input, board, user_board):
    debug("try_filling_square() called,")

    # display instructions/reprompt (but only when 'e' was initially pressed.)
    if user_input == "prompt":
        print("\n"
            "Enter the coordinates of the square you would like to edit.\n"
            "They can only a combination of one letter and one number.\n"
            "Letter must be in range from A to I.\n"
            "Number must be in range from 1 to 9.\n"
        )
        user_input = input("Please enter coordinates: ").capitalize()

    # validate input    
    if not validate_input(user_input):
        print("Invalid user input.")
    else:
        debug("user input validated.")

        # check if square was filled
        if not is_filled_square(user_input, board):
            debug("Square is free to edit.")

            # edit board
            user_board = edit_board(user_input, board, user_board)

            # display board
            display_board(board, user_board)


def edit_board(user_input, board, user_board):
    debug("edit_board() called.")

    # prompt user for a number to fill the square with
    value = get_int("Please enter a number:   ")

    # apply game rules
    if not apply_game_rules(user_input, get_combined_board(board, user_board), value):

        # if game rules were validated, leave function without editing
        return user_board

    # get row/column indexes
    letter = str(user_input[0])
    number = int(user_input[1])
    debug(f"square: '{letter}{number}'")
    row     = number - 1
    column  = column_positions[letter]

    # edit square
    print(f"Assigning {value} to {user_input}.")

    user_board[row][column] = value
    debug("New value (in user board):", user_board[row][column])
    from debug import DEBUG
    if DEBUG:
        print("New user board:")
        display_board(get_empty_board(), user_board)

    return user_board


"""
BOARD: DISPLAY
"""
def display_board(board, user_board):
    print(get_board(get_combined_board(board, user_board)))


def get_board(whichever_board):
    board_str = "\n   A B C   D E F   G H I \n"

    for i, row in enumerate(whichever_board):
        if i == 3 or i == 6: board_str += "\n   - - - + - - - + - - -"
        board_str += f"\n{i + 1}  "

        for j, value in enumerate(row):
            if value == 0: board_str += "  "
            else: board_str += f"{value} "
            if j == 2 or j == 5: board_str += "| "

    return board_str


from file_interaction import get_empty_board
def get_combined_board(board, user_board):
    combined_board = get_empty_board()
    for i, row in enumerate(combined_board):
        for j, column in enumerate(row):
            if   board[i][j]      != 0: combined_board[i][j] = board[i][j]
            elif user_board[i][j] != 0: combined_board[i][j] = user_board[i][j]

    return combined_board


"""
COMMANDS
"""
commands = {
    "COMMAND"   : "DESCRIPTION",
    "-------"   : "------------",
    "q"         : "Save and Quit Game",
    "w"         : "Quit Game (without saving)",
    "c"         : "View Commands Again",
    "d"         : "Display Board",
    "e"         : "Edit Square (Enter Coordinates)"
}

def display_commands():
    # display commands
    print("\nTo use this program, please enter any of the following:")
    for command in commands:
        print(f"{command:8}: {commands[command]}")


"""
OTHER
(Helper function for prompt)
"""
def get_int(*prompt):
    for i in range(2):
        try:
            txt = ""
            for text in prompt: txt += text + " "; prompt = txt
            return int(input(prompt))
        except ValueError as error: print(error)
        else: break

