"""
Program: Lab 05 - Sudoku
MAIN AND UI MODULES
Elijah Harrison
Description: Play Sudoku!
"""

# main module
# (other modules imported and aviailable for use before main is run)
def main():
    debug("in main.py: main called")

    # get board from file
    filename, board = load_board()

    # user board
    user_board_filename, user_board = load_user_board()

    # initiate ui
    user_interaction(board, user_board)

    # save board...
    success = save_board(user_board_filename, user_board)
    if success: print("File save success.")
    else: print("Unable to save file.")


# user interaction module
def user_interaction(board, user_board):
    debug("in main.py: ui() called.")

    # display commands
    display_commands()

    # loop prompt
    user_board = prompt(board, user_board)


# read/write to file
from file_interaction import load_board
from file_interaction import load_user_board
from file_interaction import save_board

# user interaction functions
from ui import display_commands
from ui import prompt 

# debug function
from debug import debug

# run
if __name__ == "__main__": main()

