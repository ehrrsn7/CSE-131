"""
Program: Lab 05 - Sudoku
VALIDATION MODULES
"""

# TODO: FILL IN THESE STUB FUNCTIONS

def validate_input(user_input): return True
def is_filled_square(user_input, board, user_board): return True
def was_user_filled(): pass
def apply_game_rules(): pass
