"""
Program: Lab 05 - Sudoku
UI MODULES
"""
from debug import debug
from validation import (
    validate_input,
    is_filled_square
)

def prompt(board, user_board):
    debug("in ui.py: prompt() called.")
    for i in range(200):

        # display prompt
        user_input = input("> ").capitalize()

        if   user_input == 'Q': return user_board
        elif user_input == 'C': display_commands()
        else: try_filling_square(user_input, board, user_board)

        print()


def try_filling_square(user_input, board, user_board):
    if validate_input(user_input):
        if is_filled_square(user_input, board, user_board):
            user_board = edit_board(user_input, user_board)


def edit_board(user_input, user_board):
    value = input("Please enter a number: ")
    print(f"Assigning {value} to {user_input}.")
    return user_board


def display_commands():
    # define commands
    commands = {
        "COMMAND"   : "DESCRIPTION",
        "-------"   : "------------",
        "q"         : "Save and Quit Game",
        "c"         : "View Commands Again",
        "d"         : "Display Board",
        "Letter-number combination (ex: 'A1')": "Edit Square"
    }

    # display commands
    print("\nTo use this program, please enter any of the following:")
    for command in commands:
        print(f"{command:8}: {commands[command]}")

