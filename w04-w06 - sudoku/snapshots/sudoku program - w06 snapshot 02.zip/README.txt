To run program, run Lab06.py

All other modules lie in any of the other script files, of type .py

Board .txt files lie in subfolder, called boards

